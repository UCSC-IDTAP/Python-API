from enum import Enum

class Instrument(Enum):
    Sitar = 'Sitar'
    Vocal_M = 'Vocal (M)'
    Vocal_F = 'Vocal (F)'
